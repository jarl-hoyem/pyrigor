"""PYR403 checker: flag single-parameter functions with a positional parameter."""

import ast

from pyrigor.checkers._shared import WalkedNodes, count_parameters, find_function_violations
from pyrigor.rules import Rule
from pyrigor.violations import Violation


def _has_violation(*, node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """Check whether a function definition violates PYR403.

    Args:
        node: The function definition to check.

    Returns:
        True if the function has exactly one parameter (beyond an
        optional leading self/cls), and that parameter is positional
        rather than already keyword-only.
    """
    counts = count_parameters(node=node)
    if counts.total_params != 1:
        return False

    return bool(counts.positional_args)


def find_violations(*, nodes: WalkedNodes) -> list[Violation]:
    """Find PYR403 violations in already-walked nodes.

    Args:
        nodes: Every relevant node in the file, from walk_once.

    Returns:
        A list of violations found, one per offending function.
    """
    # noinspection PyTypeChecker
    return find_function_violations(nodes=nodes.function_nodes, predicate=_has_violation, rule=Rule.PYR403)
