"""Opt-in fixer for PYR402 keyword-only arguments."""
# The fixer mirrors test cases to preserve exact source behaviour.
# pylint: disable=duplicate-code

import ast
from enum import Enum
from typing import Final, NamedTuple

from pyrigor.checkers import walk_once
from pyrigor.checkers.pyr402_keyword_only_arguments import find_violations as find_pyr402_violations
from pyrigor.findings import PositionIndex
from pyrigor.suppression import filter_suppressed

_MINIMUM_POSITIONAL_PARAMETERS: Final = 2

__all__ = ["FixRejectedError", "FixResult", "FixStatus", "fix_source"]


class FixRejectedError(ValueError):
    """Raised when a PYR402 edit could change positional-call semantics."""


class FixStatus(Enum):
    """Describe whether a source fix was applied or is only prospective."""

    UNCHANGED = "unchanged"
    CHANGED = "changed"
    WOULD_CHANGE = "would_change"


class FixResult(NamedTuple):
    """Result of a PYR402 source fix attempt."""

    source: str | bytes
    status: FixStatus


class _Insertion(NamedTuple):
    """Describe one source insertion."""

    position: int
    text: str


def fix_source(*, source: str | bytes, dry_run: bool = False) -> FixResult:
    """Insert bare stars into safe fixable signatures with kept PYR402 violations."""
    original = source
    text = source.decode() if isinstance(source, bytes) else source
    tree = ast.parse(text)
    raw = text.encode()
    index = PositionIndex(raw=raw)
    nodes = walk_once(tree=tree)
    violations = find_pyr402_violations(nodes=nodes)
    kept = filter_suppressed(violations=violations, source=text).kept
    target_positions = {(violation.line, violation.column) for violation in kept}
    edits = _source_edits(
        text=text,
        raw=raw,
        nodes=nodes.function_nodes,
        target_positions=target_positions,
        index=index,
    )

    if not edits:
        return FixResult(source=original, status=FixStatus.UNCHANGED)
    if dry_run:
        return FixResult(source=original, status=FixStatus.WOULD_CHANGE)

    return FixResult(
        source=_apply_edits(text=text, edits=edits, as_bytes=isinstance(source, bytes)), status=FixStatus.CHANGED
    )


def _apply_edits(*, text: str, edits: list[_Insertion], as_bytes: bool) -> str | bytes:
    """Apply source edits from right to left and preserve the input type."""
    for position, insertion in reversed(edits):
        text = "".join((text[:position], insertion, text[position:]))
    return text.encode() if as_bytes else text


def _source_edits(
    *,
    text: str,
    raw: bytes,
    nodes: list[ast.FunctionDef | ast.AsyncFunctionDef],
    target_positions: set[tuple[int, int]],
    index: PositionIndex,
) -> list[_Insertion]:
    """Collect safe edits for functions with kept PYR402 violations."""
    edits: list[_Insertion] = []
    for node in nodes:
        if (node.lineno, node.col_offset + 1) not in target_positions:
            continue
        edit = _function_edit(text=text, raw=raw, node=node, index=index)
        if edit is not None:
            edits.append(edit)
    return edits


def _function_edit(
    *, text: str, raw: bytes, node: ast.FunctionDef | ast.AsyncFunctionDef, index: PositionIndex
) -> _Insertion | None:
    """Return a safe insertion for one function if it needs fixing."""
    if node.args.posonlyargs:
        raise FixRejectedError(f"positional-only parameters in {node.name}")
    positional = node.args.args
    if len(positional) < _MINIMUM_POSITIONAL_PARAMETERS or node.args.vararg is not None:
        return None
    return _function_insertion(text=text, raw=raw, node=node, positional=positional, index=index)


def _function_insertion(
    *,
    text: str,
    raw: bytes,
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    positional: list[ast.arg],
    index: PositionIndex,
) -> _Insertion:
    """Return a source insertion for an eligible function.

    The search below has no end bound. `node.lineno`/`col_offset` always lands on the `def`
    (or `async`) keyword itself, past any decorator. The function's own name is therefore the
    only text between `start` and its opening parenthesis. The first "(" found from `start` is
    therefore always this function's own, regardless of what a later function in the file
    contains.
    """
    start_byte = index.byte_offset(line=node.lineno, utf8_column=node.col_offset)
    start = len(raw[:start_byte].decode())
    opening = text.find("(", start)
    if opening == -1:
        raise FixRejectedError(f"unsupported signature in {node.name}")
    return _parameter_insertion(text=text, node=node, positional=positional, opening=opening)


def _parameter_insertion(
    *, text: str, node: ast.FunctionDef | ast.AsyncFunctionDef, positional: list[ast.arg], opening: int
) -> _Insertion:
    """Return the insertion point and text for a safe signature edit.

    The comma search below has no end bound either. It only runs for a self/cls method.
    `_function_edit`'s own `_MINIMUM_POSITIONAL_PARAMETERS` guard already requires at least one
    parameter after self/cls, so a real separating comma always exists before this function's
    own body. That comma is always the first one to be found from `opening`.
    """
    if positional[0].arg not in {"self", "cls"}:
        return _Insertion(opening + 1, "*, ")
    comma = text.find(",", opening)
    if comma == -1:
        raise FixRejectedError(f"unsupported signature in {node.name}")
    return _Insertion(comma + 1, " *,")
